#
# Example file for working with os.path module
# LinkedIn Learning Python course by Joe Marini
#

import os               # this module provides a portable way of using operating system dependent functionality, useful when you want to manipulate paths
from os import path     # posix = portable operating system interface for UNIX
import datetime         # posix-mac, nt-windows
from datetime import date, time, timedelta
import time


def main():
    # Print the name of the OS
    # print(os.name)      # nt is an official name of windows
    
    # # Check for item existence and type
    # print("Item exists:", str(path.exists("textfile.txt")))
    # print("Item is a file:", path.isfile("textfile.txt"))
    # print("Item is a directory:", path.isdir("textfile.txt"))
    
    # # Work with file paths
    # print("Item's path:", path.realpath("textfile.txt"))
    # print("Item's path and name:", path.split(path.realpath("textfile.txt")))
    
    # Get the modification time
    t = time.ctime(path.getmtime("textfile.txt"))
    print(t)
    # below: get modification time function to construct a datetime object using fromstamp function which is built into time class
    print(datetime.datetime.fromtimestamp(path.getmtime("textfile.txt")))        # datetime module has datetime class in it

    # Calculate how long ago the item was modified
    td = datetime.datetime.now() - datetime.datetime.fromtimestamp(path.getmtime("textfile.txt"))
    print("It has been", td, "since the file was modified")
    print("Or", td.total_seconds(), "seconds")


def futuredates():
    # Using current time
    ini_time_for_now = datetime.datetime.now()

    # printing initial date
    print("initial_date", str(ini_time_for_now))

    # calculating future dates
    future_date_after_2yrs = ini_time_for_now + timedelta(days=730)
    future_date_after_2days = ini_time_for_now + timedelta(days=2)

    # printing calculated future dates:
    print("future date after 2 years is:", str(future_date_after_2yrs))
    print("future date after 2 days is:", str(future_date_after_2days))

    # printing calculated past days:
    past_date_before_2yrs = ini_time_for_now - timedelta(days=730)
    past_date_before_2days = ini_time_for_now - timedelta(days=2, seconds=30, minutes = 20, hours = 3)

    # printing calculated past dates:
    print("past date 2 yrs ago:", str(past_date_before_2yrs))
    print("past date 2 days ago and some minutes", str(past_date_before_2days))

    # calculated difference
    print('Time difference:', str(future_date_after_2days - ini_time_for_now))


if __name__ == "__main__":
   main()


#futuredates()